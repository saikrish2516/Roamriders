/*
  # Add Vehicle Management Features

  1. Changes
    - Add image_url column to vehicles table
    - Add is_deleted column for soft deletes
    - Add last_modified column for tracking changes
    - Add admin-specific policies for vehicle management

  2. Security
    - Only admins can modify vehicle data
    - Implement soft deletes for data preservation
*/

-- Add new columns to vehicles table
ALTER TABLE vehicles 
  ADD COLUMN IF NOT EXISTS image_url text,
  ADD COLUMN IF NOT EXISTS is_deleted boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_modified timestamptz DEFAULT now();

-- Create trigger to update last_modified
CREATE OR REPLACE FUNCTION update_last_modified()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_modified = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER vehicles_last_modified
  BEFORE UPDATE ON vehicles
  FOR EACH ROW
  EXECUTE FUNCTION update_last_modified();

-- Add admin-specific policies for vehicle management
CREATE POLICY "Admins can insert vehicles"
  ON vehicles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.jwt() ->> 'email' LIKE '%@roamrider.com');

CREATE POLICY "Admins can update vehicles"
  ON vehicles
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@roamrider.com');

CREATE POLICY "Admins can delete vehicles"
  ON vehicles
  FOR DELETE
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@roamrider.com');