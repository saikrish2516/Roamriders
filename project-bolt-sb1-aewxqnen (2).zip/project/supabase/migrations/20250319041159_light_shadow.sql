/*
  # Initial Schema Setup for RoamRider

  1. New Tables
    - users
      - id (uuid, primary key)
      - phone (text, unique)
      - full_name (text)
      - created_at (timestamp)
    
    - vehicles
      - id (uuid, primary key)
      - name (text)
      - type (text)
      - capacity (integer)
      - price_per_day (integer)
      - is_available (boolean)
      - created_at (timestamp)
    
    - bookings
      - id (uuid, primary key)
      - user_id (uuid, references users)
      - vehicle_id (uuid, references vehicles)
      - pickup_location (text)
      - drop_location (text)
      - travel_date (timestamp)
      - status (text)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT auth.uid(),
  phone text UNIQUE NOT NULL,
  full_name text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Vehicles table
CREATE TABLE vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL,
  capacity integer NOT NULL,
  price_per_day integer NOT NULL,
  is_available boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view vehicles"
  ON vehicles
  FOR SELECT
  TO authenticated
  USING (true);

-- Bookings table
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  vehicle_id uuid REFERENCES vehicles(id),
  pickup_location text NOT NULL,
  drop_location text NOT NULL,
  travel_date timestamptz NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create bookings"
  ON bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Initial vehicle data
INSERT INTO vehicles (name, type, capacity, price_per_day) VALUES
  ('Toyota Innova Crysta', 'SUV', 7, 3000),
  ('Mercedes-Benz E-Class', 'Luxury', 5, 8000),
  ('Toyota Fortuner', 'SUV', 7, 5000),
  ('Honda City', 'Sedan', 5, 2500),
  ('Tempo Traveller', 'Mini Bus', 12, 6000),
  ('Force Traveller', 'Mini Bus', 14, 7000),
  ('Toyota Commuter', 'Mini Bus', 12, 6500);