import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { AdminDashboard } from '../components/AdminDashboard';
import { Shield, LogOut, Car, Plus, Edit, Trash2, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

function Admin() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [vehicles, setVehicles] = useState([]);
  const [isAddingVehicle, setIsAddingVehicle] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [vehicleForm, setVehicleForm] = useState({
    name: '',
    type: '',
    capacity: '',
    price_per_day: '',
    image_url: '',
  });

  // Check if user is an admin
  const isAdmin = user?.email?.endsWith('@roamrider.com');

  useEffect(() => {
    if (isAdmin) {
      fetchVehicles();
    }
  }, [isAdmin]);

  const fetchVehicles = async () => {
    try {
      const { data, error } = await supabase
        .from('vehicles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
    } catch (error) {
      toast.error('Failed to fetch vehicles');
      console.error('Error:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleVehicleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { error } = editingVehicle
        ? await supabase
            .from('vehicles')
            .update({
              name: vehicleForm.name,
              type: vehicleForm.type,
              capacity: parseInt(vehicleForm.capacity),
              price_per_day: parseInt(vehicleForm.price_per_day),
              image_url: vehicleForm.image_url,
            })
            .eq('id', editingVehicle.id)
        : await supabase.from('vehicles').insert([
            {
              name: vehicleForm.name,
              type: vehicleForm.type,
              capacity: parseInt(vehicleForm.capacity),
              price_per_day: parseInt(vehicleForm.price_per_day),
              image_url: vehicleForm.image_url,
            },
          ]);

      if (error) throw error;

      toast.success(
        editingVehicle ? 'Vehicle updated successfully' : 'Vehicle added successfully'
      );
      setIsAddingVehicle(false);
      setEditingVehicle(null);
      setVehicleForm({
        name: '',
        type: '',
        capacity: '',
        price_per_day: '',
        image_url: '',
      });
      fetchVehicles();
    } catch (error) {
      toast.error('Failed to save vehicle');
      console.error('Error:', error);
    }
  };

  const handleDeleteVehicle = async (id) => {
    if (!window.confirm('Are you sure you want to delete this vehicle?')) return;

    try {
      const { error } = await supabase.from('vehicles').delete().eq('id', id);
      if (error) throw error;

      toast.success('Vehicle deleted successfully');
      fetchVehicles();
    } catch (error) {
      toast.error('Failed to delete vehicle');
      console.error('Error:', error);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-xl shadow-lg max-w-md w-full">
          <div className="text-center">
            <Shield className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
            <p className="text-gray-600 mb-4">
              You don't have permission to access the admin dashboard.
            </p>
            <button
              onClick={() => navigate('/')}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition duration-200"
            >
              Return to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600 mr-2" />
              <h1 className="text-2xl font-bold text-gray-900">RoamRider Admin</h1>
            </div>
            <button
              onClick={handleSignOut}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <LogOut className="h-5 w-5 mr-2" />
              Sign Out
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Vehicle Management Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold">Vehicle Management</h2>
            <button
              onClick={() => setIsAddingVehicle(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-full flex items-center hover:bg-blue-700"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add Vehicle
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Vehicle
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Capacity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Price/Day
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {vehicles.map((vehicle) => (
                  <tr key={vehicle.id}>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <Car className="h-5 w-5 text-gray-400 mr-2" />
                        {vehicle.name}
                      </div>
                    </td>
                    <td className="px-6 py-4">{vehicle.type}</td>
                    <td className="px-6 py-4">{vehicle.capacity} seats</td>
                    <td className="px-6 py-4">₹{vehicle.price_per_day}</td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-2">
                        <button
                          onClick={() => {
                            setEditingVehicle(vehicle);
                            setVehicleForm({
                              name: vehicle.name,
                              type: vehicle.type,
                              capacity: vehicle.capacity.toString(),
                              price_per_day: vehicle.price_per_day.toString(),
                              image_url: vehicle.image_url || '',
                            });
                          }}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => handleDeleteVehicle(vehicle.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bookings Dashboard */}
        <AdminDashboard />
      </div>

      {/* Add/Edit Vehicle Modal */}
      {(isAddingVehicle || editingVehicle) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">
                {editingVehicle ? 'Edit Vehicle' : 'Add New Vehicle'}
              </h3>
              <button
                onClick={() => {
                  setIsAddingVehicle(false);
                  setEditingVehicle(null);
                  setVehicleForm({
                    name: '',
                    type: '',
                    capacity: '',
                    price_per_day: '',
                    image_url: '',
                  });
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleVehicleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Vehicle Name
                </label>
                <input
                  type="text"
                  value={vehicleForm.name}
                  onChange={(e) =>
                    setVehicleForm({ ...vehicleForm, name: e.target.value })
                  }
                  className="w-full border-gray-300 rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Type
                </label>
                <select
                  value={vehicleForm.type}
                  onChange={(e) =>
                    setVehicleForm({ ...vehicleForm, type: e.target.value })
                  }
                  className="w-full border-gray-300 rounded-lg"
                  required
                >
                  <option value="">Select type</option>
                  <option value="luxury">Luxury</option>
                  <option value="suv">SUV</option>
                  <option value="sedan">Sedan</option>
                  <option value="minibus">Mini Bus</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Capacity (seats)
                </label>
                <input
                  type="number"
                  value={vehicleForm.capacity}
                  onChange={(e) =>
                    setVehicleForm({ ...vehicleForm, capacity: e.target.value })
                  }
                  className="w-full border-gray-300 rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Price per Day (₹)
                </label>
                <input
                  type="number"
                  value={vehicleForm.price_per_day}
                  onChange={(e) =>
                    setVehicleForm({ ...vehicleForm, price_per_day: e.target.value })
                  }
                  className="w-full border-gray-300 rounded-lg"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Image URL
                </label>
                <input
                  type="url"
                  value={vehicleForm.image_url}
                  onChange={(e) =>
                    setVehicleForm({ ...vehicleForm, image_url: e.target.value })
                  }
                  className="w-full border-gray-300 rounded-lg"
                  placeholder="https://example.com/image.jpg"
                  required
                />
              </div>

              <div className="flex justify-end space-x-4 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setIsAddingVehicle(false);
                    setEditingVehicle(null);
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
                >
                  {editingVehicle ? 'Update Vehicle' : 'Add Vehicle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Admin;