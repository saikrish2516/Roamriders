import React from 'react';
import { HeadphonesIcon, Mail, Phone } from 'lucide-react';

function Support() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold text-center mb-12">Customer Support</h1>
      
      <div className="bg-white rounded-lg shadow-lg p-8">
        <div className="flex items-center justify-center mb-8">
          <HeadphonesIcon className="h-12 w-12 text-blue-600" />
        </div>
        
        <div className="space-y-6 text-center">
          <div>
            <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
            <div className="flex items-center justify-center space-x-4">
              <Phone className="h-5 w-5 text-blue-600" />
              <p>+91 1234567890</p>
            </div>
            <div className="flex items-center justify-center space-x-4 mt-2">
              <Mail className="h-5 w-5 text-blue-600" />
              <p>support@travelwidus.com</p>
            </div>
          </div>
          
          <div>
            <h2 className="text-xl font-semibold mb-2">24/7 Support</h2>
            <p className="text-gray-600">Our team is available round the clock to assist you</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Support;