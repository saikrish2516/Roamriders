import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Car, Users, Fuel, Battery, 
  Calendar, IndianRupee, Star,
  ChevronRight, Filter, MapPin
} from 'lucide-react';
import { AuthModal } from '../components/AuthModal';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

function Cars() {
  const { user } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [priceRange, setPriceRange] = useState([1000, 10000]);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [bookingDetails, setBookingDetails] = useState({
    pickup_location: '',
    drop_location: '',
    travel_date: '',
  });

  const categories = [
    { id: 'all', name: 'All Vehicles' },
    { id: 'luxury', name: 'Luxury' },
    { id: 'suv', name: 'SUV' },
    { id: 'sedan', name: 'Sedan' },
    { id: 'minibus', name: 'Mini Bus' }
  ];

  const vehicles = [
    {
      id: 1,
      name: 'Mercedes-Benz E-Class',
      category: 'luxury',
      price: 8000,
      image: 'https://images.unsplash.com/photo-1617469767053-d3b523a0b982?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      specs: {
        seats: 5,
        fuel: 'Petrol',
        rating: 4.9
      }
    },
    {
      id: 2,
      name: 'Toyota Fortuner',
      category: 'suv',
      price: 5000,
      image: 'https://images.unsplash.com/photo-1559416523-140ddc3d238c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      specs: {
        seats: 7,
        fuel: 'Diesel',
        rating: 4.7
      }
    },
    {
      id: 3,
      name: 'Honda City',
      category: 'sedan',
      price: 3000,
      image: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      specs: {
        seats: 5,
        fuel: 'Petrol',
        rating: 4.5
      }
    },
    {
      id: 4,
      name: 'Tempo Traveller',
      category: 'minibus',
      price: 6000,
      image: 'https://images.unsplash.com/photo-1464219789935-c2d9d9aba644?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      specs: {
        seats: 12,
        fuel: 'Diesel',
        rating: 4.6
      }
    }
  ];

  const filteredVehicles = vehicles.filter(vehicle => 
    (selectedCategory === 'all' || vehicle.category === selectedCategory) &&
    vehicle.price >= priceRange[0] && vehicle.price <= priceRange[1]
  );

  const handleBooking = async (vehicle) => {
    if (!user) {
      setSelectedVehicle(vehicle);
      setIsAuthModalOpen(true);
      return;
    }

    // Show booking form modal
    setSelectedVehicle(vehicle);
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const { data, error } = await supabase
        .from('bookings')
        .insert([
          {
            user_id: user.id,
            vehicle_id: selectedVehicle.id,
            ...bookingDetails
          }
        ]);

      if (error) throw error;

      toast.success('Booking submitted successfully!');
      setSelectedVehicle(null);
      setBookingDetails({
        pickup_location: '',
        drop_location: '',
        travel_date: ''
      });
    } catch (error) {
      toast.error('Failed to submit booking');
      console.error('Booking error:', error);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <motion.div 
        className="text-center mb-12"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold mb-4">Book Your Travel Vehicle</h1>
        <p className="text-xl text-gray-600">Choose from our wide range of vehicles with professional drivers</p>
      </motion.div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-12">
        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5 text-blue-600" />
            <span className="font-medium">Filters:</span>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-2 rounded-full transition-all ${
                  selectedCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Vehicles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredVehicles.map((vehicle, index) => (
          <motion.div
            key={vehicle.id}
            className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <div className="relative">
              <img 
                src={vehicle.image} 
                alt={vehicle.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center">
                <Star className="h-4 w-4 text-yellow-400 mr-1" />
                <span className="text-sm font-medium">{vehicle.specs.rating}</span>
              </div>
            </div>

            <div className="p-6">
              <h3 className="text-xl font-semibold mb-4">{vehicle.name}</h3>
              
              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center text-gray-600">
                  <Users className="h-4 w-4 mr-1" />
                  <span className="text-sm">{vehicle.specs.seats} Seats</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Fuel className="h-4 w-4 mr-1" />
                  <span className="text-sm">{vehicle.specs.fuel}</span>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <IndianRupee className="h-4 w-4 text-blue-600 mr-1" />
                  <span className="text-xl font-semibold text-blue-600">₹{vehicle.price}/day</span>
                </div>
                <button 
                  onClick={() => handleBooking(vehicle)}
                  className="bg-blue-600 text-white px-4 py-2 rounded-full flex items-center group hover:bg-blue-700 transition-colors"
                >
                  Book Now
                  <ChevronRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Booking Modal */}
      {selectedVehicle && user && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <h3 className="text-2xl font-bold mb-4">Book {selectedVehicle.name}</h3>
            <form onSubmit={handleBookingSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Pickup Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={bookingDetails.pickup_location}
                    onChange={(e) => setBookingDetails({
                      ...bookingDetails,
                      pickup_location: e.target.value
                    })}
                    className="pl-10 w-full border-gray-300 rounded-lg"
                    placeholder="Enter pickup location"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Drop Location
                </label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={bookingDetails.drop_location}
                    onChange={(e) => setBookingDetails({
                      ...bookingDetails,
                      drop_location: e.target.value
                    })}
                    className="pl-10 w-full border-gray-300 rounded-lg"
                    placeholder="Enter drop location"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Travel Date
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="datetime-local"
                    value={bookingDetails.travel_date}
                    onChange={(e) => setBookingDetails({
                      ...bookingDetails,
                      travel_date: e.target.value
                    })}
                    className="pl-10 w-full border-gray-300 rounded-lg"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => setSelectedVehicle(null)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
                >
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
      />
    </div>
  );
}

export default Cars;