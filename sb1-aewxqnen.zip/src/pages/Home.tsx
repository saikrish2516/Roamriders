import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  MapPin, Star, Shield, Clock, Car, PenTool, 
  Users, Award, PhoneCall, Route, Calendar, 
  CreditCard, Smile, ChevronRight, MapPinned, 
  Sparkles, Shield as ShieldIcon, Bus
} from 'lucide-react';

function Home() {
  const [isHovered, setIsHovered] = useState<number | null>(null);

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const stats = [
    { number: "10K+", label: "Happy Travelers", icon: Smile },
    { number: "500+", label: "Destinations", icon: MapPinned },
    { number: "50+", label: "Expert Drivers", icon: Users },
    { number: "24/7", label: "Customer Support", icon: PhoneCall }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section with Parallax Effect */}
      <div 
        className="h-screen bg-cover bg-center relative overflow-hidden"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/60">
          <motion.div 
            className="h-full flex items-center justify-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-center text-white max-w-5xl px-4">
              <motion.h1 
                className="text-7xl font-bold mb-6 leading-tight"
                {...fadeInUp}
              >
                Your Journey, Our Responsibility
              </motion.h1>
              <motion.p 
                className="text-2xl mb-12 leading-relaxed"
                {...fadeInUp}
                transition={{ delay: 0.2 }}
              >
                Experience hassle-free travel across India with RoamRider's professional drivers and comfortable vehicles
              </motion.p>
              <motion.div 
                className="flex gap-6 justify-center"
                {...fadeInUp}
                transition={{ delay: 0.4 }}
              >
                <Link 
                  to="/cars" 
                  className="bg-blue-600 text-white px-10 py-4 rounded-full text-lg font-semibold hover:bg-blue-700 transition duration-300 flex items-center group"
                >
                  <Bus className="mr-2 h-5 w-5" />
                  Book a Trip
                  <ChevronRight className="ml-2 h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link 
                  to="/packages" 
                  className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-full text-lg font-semibold hover:bg-white/20 transition duration-300 flex items-center"
                >
                  <Route className="mr-2 h-5 w-5" />
                  View Tour Packages
                </Link>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="py-16 bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="text-center text-white"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <stat.icon className="h-10 w-10 mx-auto mb-4" />
                <h3 className="text-4xl font-bold mb-2">{stat.number}</h3>
                <p className="text-white/80">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Service Highlights with Animation */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl font-bold text-gray-900 mb-4">Why Choose RoamRider?</h2>
            <p className="text-xl text-gray-600">Experience the difference with our professional travel services</p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <motion.div 
              className="bg-gray-50 rounded-2xl p-8 text-center transform hover:scale-105 transition duration-300 hover:shadow-xl"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Expert Drivers</h3>
              <p className="text-gray-600">Professional, courteous, and experienced drivers who know every route</p>
            </motion.div>
            
            <motion.div 
              className="bg-gray-50 rounded-2xl p-8 text-center transform hover:scale-105 transition duration-300 hover:shadow-xl"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Bus className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Diverse Fleet</h3>
              <p className="text-gray-600">From luxury cars to 14-seater buses, we have vehicles for every group size</p>
            </motion.div>
            
            <motion.div 
              className="bg-gray-50 rounded-2xl p-8 text-center transform hover:scale-105 transition duration-300 hover:shadow-xl"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <div className="bg-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShieldIcon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Safe Travel</h3>
              <p className="text-gray-600">Your safety is our priority with well-maintained vehicles and verified drivers</p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Popular Routes */}
      <div className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className="text-5xl font-bold text-gray-900 mb-4">Popular Routes from Hyderabad</h2>
            <p className="text-xl text-gray-600">Explore these fantastic destinations with our comfortable travel service</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                image: "https://images.unsplash.com/photo-1590766940554-153a4613d365?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "Hyderabad to Tirupati",
                description: "Spiritual journey to the sacred temple",
                duration: "12-14 hours",
                distance: "600 km"
              },
              {
                image: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "Hyderabad to Bangalore",
                description: "Journey to the Silicon Valley of India",
                duration: "8-9 hours",
                distance: "570 km"
              },
              {
                image: "https://images.unsplash.com/photo-1572767134620-798533f4115c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
                title: "Hyderabad to Hampi",
                description: "Explore the ancient ruins",
                duration: "7-8 hours",
                distance: "380 km"
              }
            ].map((route, index) => (
              <motion.div 
                key={index}
                className="bg-white rounded-2xl overflow-hidden shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                whileHover={{ y: -10 }}
              >
                <div className="relative overflow-hidden">
                  <img 
                    src={route.image} 
                    alt={route.title}
                    className="w-full h-64 object-cover transform hover:scale-110 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 text-white">
                    <p className="text-sm font-medium">{route.duration}</p>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-semibold mb-2">{route.title}</h3>
                  <p className="text-gray-600 mb-4">{route.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-500">{route.distance}</span>
                    <Link 
                      to="/cars" 
                      className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition duration-300 flex items-center group"
                    >
                      Book Now
                      <ChevronRight className="ml-1 h-4 w-4 transform group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <motion.div 
        className="py-24 bg-gradient-to-r from-blue-600 to-blue-800 relative overflow-hidden"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
      >
        <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">Ready to Start Your Journey?</h2>
          <p className="text-xl text-white/90 mb-12 max-w-2xl mx-auto">
            Book your trip with RoamRider and experience comfortable, safe travel across India
          </p>
          <Link 
            to="/cars" 
            className="bg-white text-blue-600 px-10 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 transition duration-300 inline-flex items-center group"
          >
            Book Your Trip
            <ChevronRight className="ml-2 h-5 w-5 transform group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        {/* Abstract background shapes */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full transform -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full transform translate-x-1/2 translate-y-1/2" />
        </div>
      </motion.div>
    </div>
  );
}

export default Home;