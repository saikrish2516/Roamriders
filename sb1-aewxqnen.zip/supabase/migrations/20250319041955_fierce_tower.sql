/*
  # Add Admin Role and Policies

  1. Changes
    - Add admin role to auth.users
    - Add admin-specific policies for all tables
    - Add policy to allow admins to view all bookings
    - Add policy to allow admins to update booking status

  2. Security
    - Only admins can access all user data
    - Only admins can modify booking statuses
*/

-- Add admin policies for users table
CREATE POLICY "Admins can view all users"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@roamrider.com');

-- Add admin policies for bookings table
CREATE POLICY "Admins can view all bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@roamrider.com');

CREATE POLICY "Admins can update bookings"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'email' LIKE '%@roamrider.com');